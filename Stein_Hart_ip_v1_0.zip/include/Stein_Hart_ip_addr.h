/*
 * File Name:         C:\1_HDL_Projects\Adams\simulink_learn\stein_hart\ipcore\Stein_Hart_ip_v1_0\include\Stein_Hart_ip_addr.h
 * Description:       C Header File
 * Created:           2024-07-23 17:17:51
*/

#ifndef STEIN_HART_IP_H_
#define STEIN_HART_IP_H_

#define  IPCore_Reset_Stein_Hart_ip       0x0  //write 0x1 to bit 0 to reset IP core
#define  IPCore_Timestamp_Stein_Hart_ip   0x8  //contains unique IP timestamp (yymmddHHMM): 2407231717
#define  result_Data_Stein_Hart_ip        0x100  //data register for Outport result
#define  valid_out_Data_Stein_Hart_ip     0x104  //data register for Outport valid_out

#endif /* STEIN_HART_IP_H_ */
